#!/bin/bash

echo "==================================="
echo "  Essay Analyzer Pro - Launcher"
echo "==================================="
echo ""

# Check if Python is installed
if ! command -v python &> /dev/null
then
    echo "Python not found! Please install Python 3.8+"
    exit 1
fi

# Check if Node is installed
if ! command -v node &> /dev/null
then
    echo "Node.js not found! Please install Node.js 18+"
    exit 1
fi

echo "Installing backend dependencies..."
cd backend
pip install -q fastapi uvicorn pydantic python-multipart 2>/dev/null || pip3 install -q fastapi uvicorn pydantic python-multipart 2>/dev/null
echo "✓ Backend dependencies installed"

echo ""
echo "Starting backend server on http://localhost:8000"
python main.py &
BACKEND_PID=$!

# Wait for backend to start
sleep 3

cd ..

echo ""
echo "Installing frontend dependencies..."
npm install -q 2>/dev/null
echo "✓ Frontend dependencies installed"

echo ""
echo "Starting frontend on http://localhost:5173"
npm run dev &
FRONTEND_PID=$!

echo ""
echo "==================================="
echo "  Both servers are running!"
echo "==================================="
echo ""
echo "  Frontend: http://localhost:5173"
echo "  Backend:  http://localhost:8000"
echo "  API Docs: http://localhost:8000/docs"
echo ""
echo "Press Ctrl+C to stop both servers"
echo ""

# Wait for interrupt
trap "kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait
