"""
Essay Analyzer Pro - FastAPI Backend
Advanced text analysis with topic understanding, reference validation, and AI detection.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Tuple, Optional
import re
from difflib import SequenceMatcher
from collections import Counter
import uvicorn
import random

app = FastAPI(title="Essay Analyzer Pro API", version="2.0.0")

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============== DATA MODELS ==============

class EssayRequest(BaseModel):
    text: str

class HumanizeRequest(BaseModel):
    text: str
    style: str = "natural"  # natural, academic, casual

class Highlight(BaseModel):
    start: int
    end: int
    type: str
    message: str
    severity: str = "medium"  # low, medium, high

class Reference(BaseModel):
    citation: str
    type: str  # apa, mla, chicago, unknown
    is_valid_format: bool
    matches_topic: bool
    suggested_correction: Optional[str] = None

class PeerReviewedSource(BaseModel):
    title: str
    authors: str
    journal: str
    year: int
    doi: str
    relevance_score: float
    url: str

class TopicAnalysis(BaseModel):
    main_topic: str
    subtopics: List[str]
    keywords: List[str]
    confidence: float

class AdvancedAnalysisResponse(BaseModel):
    score: int
    human_score: int
    ai_probability: float
    similarity: float
    ai_phrase_count: int
    sentence_variation: float
    repeated_words: List[Dict[str, Any]]
    highlighted_text: List[Highlight]
    suggestions: List[str]
    topic_analysis: TopicAnalysis
    references: List[Reference]
    peer_reviewed_suggestions: List[PeerReviewedSource]
    writing_patterns: Dict[str, Any]
    citation_analysis: Dict[str, Any]

# ============== ENHANCED AI DETECTION PATTERNS ==============

# Advanced AI phrase patterns (like Turnitin/Copyleaks detection)
AI_PATTERNS = {
    "transitional_phrases": [
        "furthermore", "moreover", "additionally", "consequently", "therefore",
        "thus", "hence", "accordingly", "subsequently", "nevertheless",
        "nonetheless", "however", "conversely", "alternatively", "meanwhile"
    ],
    "ai_introductions": [
        "this essay will discuss", "this paper examines", "in this essay",
        "the purpose of this paper", "the aim of this study",
        "this research investigates", "the following essay",
        "in the following pages", "as we shall see"
    ],
    "ai_conclusions": [
        "in conclusion", "to conclude", "in summary", "to summarize",
        "in closing", "to wrap up", "all things considered",
        "taking everything into account", "as has been noted",
        "as previously mentioned"
    ],
    "robotic_phrases": [
        "it is important to note", "it should be noted",
        "it is worth mentioning", "it is interesting to observe",
        "it is crucial to understand", "it is essential to recognize",
        "needless to say", "it goes without saying",
        "as a matter of fact", "in actual fact"
    ],
    "generic_statements": [
        "in today's society", "in modern times", "in the contemporary world",
        "in the current era", "in recent years", "throughout history",
        "since the beginning of time", "in today's rapidly changing world",
        "in the digital age", "in the 21st century"
    ],
    "ai_fillers": [
        "delve into", "shed light on", "paint a picture",
        "at the end of the day", "when all is said and done",
        "the fact of the matter is", "the bottom line is",
        "in the grand scheme of things", "when push comes to shove"
    ],
    "academic_buzzwords": [
        "holistic approach", "paradigm shift", "going forward",
        "moving forward", "best practices", "core competencies",
        "value proposition", "thought leadership", "synergy",
        "leverage", "optimize", "streamline", "facilitate"
    ]
}

# All AI phrases flattened
ALL_AI_PHRASES = []
for category, phrases in AI_PATTERNS.items():
    ALL_AI_PHRASES.extend(phrases)

EXAMPLE_INDICATORS = [
    "for example", "for instance", "in practice", "in real life",
    "to illustrate", "such as", "namely", "specifically",
    "to demonstrate", "as an example", "case in point",
    "in particular", "particularly", "including", "like", "especially",
    "evidence suggests", "research shows", "studies indicate"
]

# Peer-reviewed reference database (simulated)
PEER_REVIEWED_DATABASE = {
    "climate change": [
        {
            "title": "Climate Change 2021: The Physical Science Basis",
            "authors": "IPCC",
            "journal": "Cambridge University Press",
            "year": 2021,
            "doi": "10.1017/9781009157896",
            "url": "https://www.ipcc.ch/report/ar6/wg1/"
        },
        {
            "title": "Global warming and changes in drought",
            "authors": "Trenberth, K.E., et al.",
            "journal": "Nature Climate Change",
            "year": 2014,
            "doi": "10.1038/nclimate2067",
            "url": "https://www.nature.com/articles/nclimate2067"
        }
    ],
    "artificial intelligence": [
        {
            "title": "Deep Learning",
            "authors": "LeCun, Y., Bengio, Y., & Hinton, G.",
            "journal": "Nature",
            "year": 2015,
            "doi": "10.1038/nature14539",
            "url": "https://www.nature.com/articles/nature14539"
        },
        {
            "title": "Attention is All You Need",
            "authors": "Vaswani, A., et al.",
            "journal": "Advances in Neural Information Processing Systems",
            "year": 2017,
            "doi": "arXiv:1706.03762",
            "url": "https://arxiv.org/abs/1706.03762"
        }
    ],
    "education": [
        {
            "title": "Visible Learning: A Synthesis of Over 800 Meta-Analyses",
            "authors": "Hattie, J.",
            "journal": "Routledge",
            "year": 2009,
            "doi": "10.4324/9780203887332",
            "url": "https://www.routledge.com/Visible-Learning/Hattie/p/book/9780415476188"
        },
        {
            "title": "The Impact of Digital Technology on Learning",
            "authors": "Higgins, S., et al.",
            "journal": "Education Endowment Foundation",
            "year": 2012,
            "doi": "10.13140/RG.2.1.3156.4722",
            "url": "https://educationendowmentfoundation.org.uk/"
        }
    ],
    "psychology": [
        {
            "title": "Thinking, Fast and Slow",
            "authors": "Kahneman, D.",
            "journal": "Farrar, Straus and Giroux",
            "year": 2011,
            "doi": "10.5860/choice.49-2396",
            "url": "https://us.macmillan.com/books/9780374533557"
        },
        {
            "title": "The Role of Deliberate Practice in Expert Performance",
            "authors": "Ericsson, K.A., et al.",
            "journal": "Psychological Review",
            "year": 1993,
            "doi": "10.1037/0033-295X.100.3.363",
            "url": "https://psycnet.apa.org/record/1993-40718-001"
        }
    ],
    "economics": [
        {
            "title": "Capital in the Twenty-First Century",
            "authors": "Piketty, T.",
            "journal": "Harvard University Press",
            "year": 2014,
            "doi": "10.4159/9780674369542",
            "url": "https://www.hup.harvard.edu/books/9780674979857"
        },
        {
            "title": "Nudge: Improving Decisions About Health, Wealth",
            "authors": "Thaler, R.H. & Sunstein, C.R.",
            "journal": "Yale University Press",
            "year": 2008,
            "doi": "10.12987/9780300146811",
            "url": "https://yalebooks.yale.edu/book/9780300122235/nudge"
        }
    ],
    "healthcare": [
        {
            "title": "To Err Is Human: Building a Safer Health System",
            "authors": "Institute of Medicine",
            "journal": "National Academy Press",
            "year": 2000,
            "doi": "10.17226/9728",
            "url": "https://nap.nationalacademies.org/catalog/9728"
        },
        {
            "title": "The Lancet Commission on Pollution and Health",
            "authors": "Landrigan, P.J., et al.",
            "journal": "The Lancet",
            "year": 2018,
            "doi": "10.1016/S0140-6736(17)32345-0",
            "url": "https://www.thelancet.com/commissions/pollution-and-health"
        }
    ],
    "technology": [
        {
            "title": "The Second Machine Age: Work, Progress",
            "authors": "Brynjolfsson, E. & McAfee, A.",
            "journal": "W.W. Norton & Company",
            "year": 2014,
            "doi": "10.1108/k.2014.06743dae.002",
            "url": "https://wwnorton.com/books/9780393239355"
        },
        {
            "title": "The Innovator's Dilemma",
            "authors": "Christensen, C.M.",
            "journal": "Harvard Business Review Press",
            "year": 1997,
            "doi": "10.1108/k.1998.06728cae.002",
            "url": "https://hbr.org/1997/05/the-innovators-dilemma"
        }
    ],
    "sustainability": [
        {
            "title": "Our Common Future (Brundtland Report)",
            "authors": "World Commission on Environment",
            "journal": "Oxford University Press",
            "year": 1987,
            "doi": "10.2307/2621529",
            "url": "https://sustainabledevelopment.un.org/content/documents/5987our-common-future.pdf"
        },
        {
            "title": "Planetary Boundaries: Guiding Human Development",
            "authors": "Steffen, W., et al.",
            "journal": "Science",
            "year": 2015,
            "doi": "10.1126/science.1259855",
            "url": "https://www.science.org/doi/10.1126/science.1259855"
        }
    ],
    "social media": [
        {
            "title": "The Social Media Debate: Unpacking the Social",
            "authors": "Bayer, J.B., et al.",
            "journal": "Journal of Communication",
            "year": 2020,
            "doi": "10.1093/joc/jqz037",
            "url": "https://academic.oup.com/joc/article/70/1/1/5733995"
        },
        {
            "title": "Social Media and Mental Health",
            "authors": "Keles, B., et al.",
            "journal": "International Journal of Environmental Research",
            "year": 2020,
            "doi": "10.3390/ijerph17061769",
            "url": "https://www.mdpi.com/1660-4601/17/6/1769"
        }
    ],
    "leadership": [
        {
            "title": "Transformational Leadership",
            "authors": "Bass, B.M. & Riggio, R.E.",
            "journal": "Psychology Press",
            "year": 2006,
            "doi": "10.4324/9781410617095",
            "url": "https://www.routledge.com/Transformational-Leadership/Bass-Riggio/p/book/9780805847628"
        },
        {
            "title": "Authentic Leadership: Development and Validation",
            "authors": "Walumbwa, F.O., et al.",
            "journal": "Journal of Management",
            "year": 2008,
            "doi": "10.1177/0149206307308913",
            "url": "https://journals.sagepub.com/doi/10.1177/0149206307308913"
        }
    ]
}

# ============== TOPIC EXTRACTION ==============

def extract_keywords(text: str) -> List[Tuple[str, int]]:
    """Extract important keywords from text using frequency and position."""
    # Clean and tokenize
    words = re.findall(r'\b[a-zA-Z]{4,}\b', text.lower())
    
    # Common stop words
    stop_words = {
        'this', 'that', 'with', 'from', 'they', 'have', 'were', 'been',
        'their', 'would', 'there', 'could', 'should', 'about', 'after',
        'before', 'being', 'these', 'those', 'while', 'during', 'under',
        'over', 'again', 'further', 'then', 'once', 'here', 'when',
        'where', 'what', 'which', 'who', 'whom', 'whose', 'why', 'how',
        'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other',
        'some', 'such', 'only', 'own', 'same', 'than', 'too', 'very',
        'just', 'also', 'well', 'only', 'even', 'back', 'still', 'way',
        'may', 'might', 'must', 'shall', 'will', 'essay', 'paper', 'study',
        'research', 'analysis', 'discuss', 'examine', 'explore', 'argue'
    }
    
    # Filter stop words and count
    filtered = [w for w in words if w not in stop_words]
    frequency = Counter(filtered)
    
    # Return top keywords
    return frequency.most_common(15)

def extract_topic_from_title(text: str) -> Optional[str]:
    """Try to extract topic from title (first line)."""
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    if not lines:
        return None
    
    first_line = lines[0]
    # Remove common title prefixes
    first_line = re.sub(r'^(the|an?|introduction\s+to)\s+', '', first_line.lower())
    
    # Extract key noun phrases
    words = re.findall(r'\b[a-zA-Z]+\b', first_line.lower())
    if len(words) >= 2:
        return ' '.join(words[:4])
    return None

def analyze_topic(text: str) -> TopicAnalysis:
    """Analyze and extract the main topic of the essay."""
    keywords = extract_keywords(text)
    
    # Get main topic from title or keywords
    title_topic = extract_topic_from_title(text)
    
    if title_topic and len(title_topic) > 5:
        main_topic = title_topic
    elif keywords:
        # Combine top 2-3 keywords for topic
        main_topic = ' '.join([k[0] for k in keywords[:2]])
    else:
        main_topic = "General Topic"
    
    # Extract subtopics (next most frequent keywords)
    subtopics = [k[0] for k in keywords[2:6]]
    
    # Calculate confidence based on keyword concentration
    total_keyword_mentions = sum(k[1] for k in keywords[:5])
    word_count = len(text.split())
    confidence = min(100, (total_keyword_mentions / word_count) * 500)
    
    return TopicAnalysis(
        main_topic=main_topic.title(),
        subtopics=subtopics,
        keywords=[k[0] for k in keywords[:10]],
        confidence=round(confidence, 2)
    )

# ============== REFERENCE EXTRACTION ==============

def extract_references(text: str) -> List[Reference]:
    """Extract and validate references from text."""
    references = []
    
    # APA style pattern (Author, Year)
    apa_pattern = r'\([A-Z][a-z]+(?:\s+&\s+[A-Z][a-z]+)?,\s+\d{4}(?:,\s+p\.?\s*\d+)?\)'
    
    # MLA style pattern (Author Page)
    mla_pattern = r'\([A-Z][a-z]+\s+\d+\)'
    
    # Full citation patterns
    full_citation_pattern = r'(?:[A-Z][a-z]+(?:,\s+[A-Z]\.?)+)?\s*\(\d{4}\)\.?\s*["\']?[^.]+["\']?\.?\s*(?:[A-Z][a-z]+\s+)?\d+\s*\(\d+\),?\s*\d+[-–]\d+'
    
    # Find all potential citations
    apa_matches = re.finditer(apa_pattern, text)
    for match in apa_matches:
        ref_text = match.group()
        references.append(Reference(
            citation=ref_text,
            type="apa",
            is_valid_format=validate_apa_citation(ref_text),
            matches_topic=True  # Will be updated later
        ))
    
    # Look for reference list
    ref_section = extract_reference_section(text)
    if ref_section:
        # Parse individual references
        ref_lines = [l.strip() for l in ref_section.split('\n') if l.strip()]
        for line in ref_lines[:10]:  # Limit to first 10
            ref_type = detect_citation_style(line)
            references.append(Reference(
                citation=line[:100] + "..." if len(line) > 100 else line,
                type=ref_type,
                is_valid_format=validate_citation_format(line, ref_type),
                matches_topic=True
            ))
    
    return references

def extract_reference_section(text: str) -> Optional[str]:
    """Extract the references/bibliography section."""
    # Common section headers
    headers = [
        r'references\s*\n',
        r'bibliography\s*\n',
        r'works\s+cited\s*\n',
        r'references\s+cited\s*\n'
    ]
    
    for pattern in headers:
        match = re.search(pattern + r'(.+?)(?:\n\n|\Z)', text, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()
    
    return None

def detect_citation_style(citation: str) -> str:
    """Detect the citation style (APA, MLA, Chicago)."""
    citation_lower = citation.lower()
    
    # APA indicators
    if re.search(r'\(\d{4}\)', citation) and re.search(r'&', citation):
        return "apa"
    
    # MLA indicators
    if re.search(r'"[^"]+"', citation) and not re.search(r'\(\d{4}\)', citation):
        return "mla"
    
    # Chicago indicators
    if re.search(r'\d{4}\)', citation):
        return "chicago"
    
    return "unknown"

def validate_apa_citation(citation: str) -> bool:
    """Validate APA citation format."""
    # Basic APA validation
    has_author = re.search(r'[A-Z][a-z]+', citation)
    has_year = re.search(r'\d{4}', citation)
    return bool(has_author and has_year)

def validate_citation_format(citation: str, style: str) -> bool:
    """Validate citation format based on style."""
    if style == "apa":
        return bool(re.search(r'[A-Z][a-z]+.*\(\d{4}\)', citation))
    elif style == "mla":
        return '"' in citation or 'Print' in citation
    elif style == "chicago":
        return bool(re.search(r'\d{4}', citation))
    return False

def suggest_peer_reviewed_references(topic: str, subtopics: List[str]) -> List[PeerReviewedSource]:
    """Suggest peer-reviewed references based on topic."""
    suggestions = []
    
    # Search database for matching topics
    topic_lower = topic.lower()
    
    for db_topic, sources in PEER_REVIEWED_DATABASE.items():
        # Check if topic matches
        relevance = calculate_topic_relevance(topic_lower, db_topic, subtopics)
        
        if relevance > 0.3:  # Threshold for relevance
            for source in sources:
                suggestions.append(PeerReviewedSource(
                    title=source["title"],
                    authors=source["authors"],
                    journal=source["journal"],
                    year=source["year"],
                    doi=source["doi"],
                    relevance_score=round(relevance * 100, 2),
                    url=source["url"]
                ))
    
    # Sort by relevance and return top 5
    suggestions.sort(key=lambda x: x.relevance_score, reverse=True)
    return suggestions[:5]

def calculate_topic_relevance(topic: str, db_topic: str, subtopics: List[str]) -> float:
    """Calculate relevance score between topic and database topic."""
    topic_words = set(topic.split())
    db_words = set(db_topic.split())
    
    # Direct match
    if topic == db_topic:
        return 1.0
    
    # Word overlap
    overlap = len(topic_words & db_words)
    total = len(topic_words | db_words)
    
    if total == 0:
        return 0.0
    
    base_score = overlap / total
    
    # Boost score if subtopics match
    for subtopic in subtopics:
        if subtopic in db_topic:
            base_score += 0.2
    
    return min(1.0, base_score)

# ============== ADVANCED AI DETECTION ==============

def detect_advanced_ai_patterns(text: str) -> Tuple[float, List[Dict]]:
    """
    Advanced AI detection similar to Copyleaks/Turnitin.
    Returns AI probability score (0-100) and detected patterns.
    """
    detected_patterns = []
    pattern_scores = {
        "transitional_phrases": 0,
        "ai_introductions": 0,
        "ai_conclusions": 0,
        "robotic_phrases": 0,
        "generic_statements": 0,
        "ai_fillers": 0,
        "academic_buzzwords": 0
    }
    
    text_lower = text.lower()
    
    # Detect each pattern category
    for category, phrases in AI_PATTERNS.items():
        for phrase in phrases:
            pattern = re.compile(re.escape(phrase), re.IGNORECASE)
            matches = list(pattern.finditer(text))
            
            for match in matches:
                detected_patterns.append({
                    "start": match.start(),
                    "end": match.end(),
                    "type": "ai_pattern",
                    "category": category,
                    "message": f"AI pattern detected: '{phrase}' ({category.replace('_', ' ')})"
                })
                pattern_scores[category] += 1
    
    # Calculate AI probability score
    total_patterns = sum(pattern_scores.values())
    word_count = len(text.split())
    
    # Base score from pattern density
    density_score = (total_patterns / word_count) * 100 if word_count > 0 else 0
    
    # Category weights (some patterns are stronger indicators)
    weights = {
        "ai_introductions": 3.0,
        "ai_conclusions": 2.5,
        "robotic_phrases": 2.0,
        "generic_statements": 1.5,
        "ai_fillers": 1.5,
        "transitional_phrases": 0.5,
        "academic_buzzwords": 0.8
    }
    
    weighted_score = sum(pattern_scores[cat] * weights[cat] for cat in pattern_scores)
    ai_probability = min(100, (weighted_score / word_count) * 150)
    
    return ai_probability, detected_patterns

def analyze_writing_patterns(text: str) -> Dict[str, Any]:
    """Analyze writing patterns for human vs AI characteristics."""
    sentences = split_sentences(text)
    
    # Sentence length consistency (AI tends to be more consistent)
    word_counts = [len(s.split()) for s in sentences]
    avg_length = sum(word_counts) / len(word_counts) if word_counts else 0
    variance = sum((x - avg_length) ** 2 for x in word_counts) / len(word_counts) if word_counts else 0
    consistency_score = 100 - (variance ** 0.5 / avg_length * 100) if avg_length > 0 else 0
    
    # Vocabulary diversity
    words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
    unique_words = len(set(words))
    total_words = len(words)
    diversity = (unique_words / total_words) * 100 if total_words > 0 else 0
    
    # First person usage (humans use more)
    first_person = len(re.findall(r'\b(I|me|my|we|our|us)\b', text, re.IGNORECASE))
    first_person_ratio = (first_person / total_words) * 100 if total_words > 0 else 0
    
    # Imperfections (humans make minor errors)
    contractions = len(re.findall(r"\b\w+'\w+\b", text))
    
    return {
        "sentence_consistency": round(consistency_score, 2),
        "vocabulary_diversity": round(diversity, 2),
        "first_person_usage": round(first_person_ratio, 2),
        "contractions_used": contractions,
        "avg_sentence_length": round(avg_length, 2),
        "indicators": {
            "high_consistency": consistency_score > 70,  # AI-like
            "low_diversity": diversity < 40,  # AI-like
            "low_first_person": first_person_ratio < 1,  # AI-like
            "few_contractions": contractions < 3  # AI-like
        }
    }

def calculate_enhanced_human_score(
    ai_probability: float,
    writing_patterns: Dict[str, Any],
    variation: float,
    repetition_count: int,
    similarity: float
) -> int:
    """
    Calculate enhanced human writing score with AI detection.
    """
    score = 100
    
    # AI probability penalty (major factor)
    if ai_probability > 50:
        score -= 30
    elif ai_probability > 30:
        score -= 20
    elif ai_probability > 15:
        score -= 10
    
    # Writing pattern penalties
    indicators = writing_patterns.get("indicators", {})
    if indicators.get("high_consistency"):
        score -= 10
    if indicators.get("low_diversity"):
        score -= 10
    if indicators.get("low_first_person"):
        score -= 5
    if indicators.get("few_contractions"):
        score -= 5
    
    # Other factors
    if variation < 30:
        score -= 10
    
    if repetition_count > 5:
        score -= 10
    
    if similarity > 20:
        score -= 15
    elif similarity > 10:
        score -= 8
    
    return max(0, min(100, score))

# ============== HUMANIZATION ==============

def humanize_text(text: str, style: str = "natural") -> str:
    """
    Humanize AI-generated text to make it more natural.
    """
    humanized = text
    
    # Replace AI phrases with natural alternatives
    replacements = {
        "furthermore": ["also", "plus", "what's more", "on top of that"],
        "moreover": ["besides", "in addition", "as well"],
        "additionally": ["also", "too", "as well"],
        "consequently": ["so", "as a result", "that's why"],
        "therefore": ["so", "that's why", "which means"],
        "thus": ["so", "this means"],
        "however": ["but", "yet", "still", "though"],
        "nevertheless": ["still", "even so", "all the same"],
        "in conclusion": ["to wrap up", "all in all", "at the end of the day"],
        "to conclude": ["to sum up", "in the end"],
        "it is important to note": ["worth noting", "keep in mind"],
        "it should be noted": ["note that", "remember"],
        "needless to say": ["obviously", "clearly"],
        "in today's society": ["these days", "nowadays", "today"],
        "throughout history": ["historically", "over time"],
        "delve into": ["explore", "look at", "examine"],
        "shed light on": ["explain", "clarify", "show"],
        "at the end of the day": ["ultimately", "when it comes down to it"],
    }
    
    for ai_phrase, alternatives in replacements.items():
        # Use random alternative for variety
        replacement = random.choice(alternatives)
        humanized = re.sub(
            re.escape(ai_phrase), 
            replacement, 
            humanized, 
            flags=re.IGNORECASE
        )
    
    # Add contractions for more natural feel
    contraction_pairs = [
        (r'\bit is\b', "it's"),
        (r'\bit was\b', "it was"),  # Keep as is
        (r'\bdo not\b', "don't"),
        (r'\bdoes not\b', "doesn't"),
        (r'\bdid not\b', "didn't"),
        (r'\bwill not\b', "won't"),
        (r'\bcannot\b', "can't"),
        (r'\bwould not\b', "wouldn't"),
        (r'\bshould not\b', "shouldn't"),
        (r'\bcould not\b', "couldn't"),
        (r'\bthey are\b', "they're"),
        (r'\bwe are\b', "we're"),
        (r'\byou are\b', "you're"),
        (r'\bI am\b', "I'm"),
        (r'\bthat is\b', "that's"),
        (r'\bthere is\b', "there's"),
    ]
    
    # Apply ~50% of contractions randomly for natural variation
    for pattern, contraction in contraction_pairs:
        if random.random() > 0.5:
            humanized = re.sub(pattern, contraction, humanized, flags=re.IGNORECASE)
    
    # Vary sentence starters (AI often uses similar patterns)
    sentences = split_sentences(humanized)
    varied_sentences = []
    
    for i, sentence in enumerate(sentences):
        # Occasionally rephrase sentences starting with "The"
        if sentence.strip().lower().startswith("the ") and random.random() > 0.7:
            # Simple rephrasing - remove "The" at start
            sentence = sentence[4:].capitalize()
        varied_sentences.append(sentence)
    
    humanized = ' '.join(varied_sentences)
    
    # Clean up spacing and capitalization
    humanized = re.sub(r'\s+', ' ', humanized).strip()
    humanized = humanized[0].upper() + humanized[1:] if humanized else ""
    
    return humanized

# ============== CITATION ANALYSIS ==============

def analyze_citations(text: str) -> Dict[str, Any]:
    """Analyze citation usage and quality."""
    
    # Count in-text citations
    apa_citations = len(re.findall(r'\([A-Z][a-z]+.*?,\s*\d{4}.*?\)', text))
    mla_citations = len(re.findall(r'\([A-Z][a-z]+\s+\d+\)', text))
    
    # Check for direct quotes
    direct_quotes = len(re.findall(r'"[^"]{10,200}"', text))
    
    # Check for paraphrasing indicators
    paraphrase_indicators = [
        "according to", "states that", "argues that", "suggests that",
        "found that", "reported that", "indicates that", "demonstrates that"
    ]
    paraphrase_count = sum(len(re.findall(rf'\b{indicator}\b', text, re.IGNORECASE)) 
                          for indicator in paraphrase_indicators)
    
    # Calculate citation density
    word_count = len(text.split())
    citation_density = ((apa_citations + mla_citations) / word_count) * 1000 if word_count > 0 else 0
    
    return {
        "apa_citations": apa_citations,
        "mla_citations": mla_citations,
        "total_citations": apa_citations + mla_citations,
        "direct_quotes": direct_quotes,
        "paraphrase_indicators": paraphrase_count,
        "citation_density": round(citation_density, 2),
        "has_reference_section": extract_reference_section(text) is not None,
        "quality_assessment": {
            "sufficient_citations": citation_density > 3,
            "good_paraphrasing": paraphrase_count > 2,
            "balanced_quotes": 0 < direct_quotes < 5
        }
    }

# ============== UTILITY FUNCTIONS ==============

def split_sentences(text: str) -> List[str]:
    """Split text into sentences."""
    text = re.sub(r'\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|vs|Vol|vol|Inc|Ltd|Co)\.', r'\1<DOT>', text)
    sentences = re.split(r'(?<=[.!?])\s+', text)
    sentences = [s.replace('<DOT>', '.').strip() for s in sentences if s.strip()]
    return sentences

def split_paragraphs(text: str) -> List[str]:
    """Split text into paragraphs."""
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    return paragraphs

def get_word_frequency(text: str) -> Dict[str, int]:
    """Calculate word frequency."""
    words = re.findall(r'\b[a-zA-Z]+\b', text.lower())
    frequency = {}
    for word in words:
        frequency[word] = frequency.get(word, 0) + 1
    return frequency

def calculate_sentence_variation(sentences: List[str], text: str) -> Tuple[float, List[Dict]]:
    """Calculate sentence length variation."""
    if len(sentences) < 2:
        return 0.0, []
    
    word_counts = [len(sentence.split()) for sentence in sentences]
    avg_length = sum(word_counts) / len(word_counts)
    
    variance = sum((x - avg_length) ** 2 for x in word_counts) / len(word_counts)
    std_dev = variance ** 0.5
    
    variation = (std_dev / avg_length) * 100 if avg_length > 0 else 0
    
    issues = []
    char_index = 0
    
    for i, sentence in enumerate(sentences):
        word_count = word_counts[i]
        sentence_start = text.find(sentence, char_index)
        sentence_end = sentence_start + len(sentence) if sentence_start >= 0 else char_index
        
        if word_count > 25:
            issues.append({
                "start": sentence_start,
                "end": sentence_end,
                "type": "long_sentence",
                "severity": "medium",
                "message": f"Very long sentence ({word_count} words). Consider breaking it up."
            })
        elif word_count < 5 and i > 0:
            issues.append({
                "start": sentence_start,
                "end": sentence_end,
                "type": "short_sentence",
                "severity": "low",
                "message": f"Very short sentence ({word_count} words). Consider combining."
            })
        
        char_index = sentence_end
    
    return variation, issues

def detect_repetition(text: str) -> Tuple[List[Dict], List[Dict]]:
    """Detect word repetition."""
    frequency = get_word_frequency(text)
    total_words = sum(frequency.values())
    
    common_words = {
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
        'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
        'will', 'would', 'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'need',
        'it', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'we', 'they',
        'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'its', 'our', 'their',
        'as', 'from', 'up', 'about', 'into', 'through', 'during', 'before', 'after',
        'between', 'among', 'within', 'without', 'against', 'under', 'over', 'again', 'then', 'once'
    }
    
    repeated = []
    for word, count in frequency.items():
        if word not in common_words and len(word) > 3:
            percentage = (count / total_words) * 100
            if percentage > 3 or count > 5:
                repeated.append({
                    "word": word,
                    "count": count,
                    "percentage": round(percentage, 2)
                })
    
    highlights = []
    for word_data in repeated:
        word = word_data["word"]
        pattern = re.compile(r'\b' + re.escape(word) + r'\b', re.IGNORECASE)
        for match in pattern.finditer(text):
            highlights.append({
                "start": match.start(),
                "end": match.end(),
                "type": "repetition",
                "severity": "medium",
                "message": f"Word repeated {word_data['count']} times: '{word}'"
            })
    
    return repeated, highlights

def calculate_similarity(text: str) -> Tuple[float, List[Dict]]:
    """Calculate internal similarity."""
    words = text.split()
    phrases = []
    
    for i in range(len(words) - 4):
        phrase = ' '.join(words[i:i+8])
        phrases.append((i, phrase.lower()))
    
    if len(phrases) < 2:
        return 0.0, []
    
    similar_pairs = []
    checked = set()
    
    for i, (idx1, phrase1) in enumerate(phrases):
        for j, (idx2, phrase2) in enumerate(phrases[i+1:], i+1):
            if abs(idx1 - idx2) < 10:
                continue
            
            pair_key = tuple(sorted([idx1, idx2]))
            if pair_key in checked:
                continue
            checked.add(pair_key)
            
            similarity = SequenceMatcher(None, phrase1, phrase2).ratio()
            if similarity > 0.7:
                start1 = sum(len(words[k]) + 1 for k in range(idx1))
                end1 = start1 + len(phrase1)
                
                similar_pairs.append({
                    "start": start1,
                    "end": end1,
                    "type": "similarity",
                    "severity": "high",
                    "message": f"Similar phrase ({int(similarity * 100)}% match). Consider rephrasing."
                })
    
    unique_phrases = len(set(p[1] for p in phrases))
    similarity_score = ((len(phrases) - unique_phrases) / len(phrases)) * 100 if phrases else 0
    
    return min(similarity_score * 5, 100), similar_pairs

# ============== API ENDPOINTS ==============

@app.get("/")
def root():
    return {"message": "Essay Analyzer Pro API", "version": "2.0.0"}

@app.post("/analyse", response_model=AdvancedAnalysisResponse)
def analyse_essay(request: EssayRequest):
    """
    Advanced essay analysis with topic understanding and AI detection.
    """
    text = request.text.strip()
    
    if not text:
        raise HTTPException(status_code=400, detail="No text provided")
    
    if len(text) < 50:
        raise HTTPException(status_code=400, detail="Text too short. Minimum 50 characters required.")
    
    # Topic analysis
    topic_analysis = analyze_topic(text)
    
    # Reference extraction and validation
    references = extract_references(text)
    
    # Peer-reviewed suggestions
    peer_suggestions = suggest_peer_reviewed_references(
        topic_analysis.main_topic, 
        topic_analysis.subtopics
    )
    
    # Advanced AI detection
    ai_probability, ai_patterns = detect_advanced_ai_patterns(text)
    
    # Writing pattern analysis
    writing_patterns = analyze_writing_patterns(text)
    
    # Citation analysis
    citation_analysis = analyze_citations(text)
    
    # Traditional analysis
    sentences = split_sentences(text)
    variation, sentence_issues = calculate_sentence_variation(sentences, text)
    
    # Count AI phrases
    ai_phrase_count = len(ai_patterns)
    
    # Repetition detection
    repeated_words, repetition_highlights = detect_repetition(text)
    
    # Similarity check
    similarity, similarity_highlights = calculate_similarity(text)
    
    # Enhanced human score
    human_score = calculate_enhanced_human_score(
        ai_probability,
        writing_patterns,
        variation,
        len(repeated_words),
        similarity
    )
    
    # Original score (for backward compatibility)
    original_score = max(0, min(100, 100 - int(ai_probability * 0.5)))
    
    # Combine all highlights
    all_highlights = []
    all_highlights.extend(sentence_issues)
    all_highlights.extend(ai_patterns)
    all_highlights.extend(repetition_highlights)
    all_highlights.extend(similarity_highlights)
    
    highlighted_text = [
        Highlight(
            start=h["start"],
            end=h["end"],
            type=h["type"],
            severity=h.get("severity", "medium"),
            message=h["message"]
        ) for h in all_highlights
    ]
    
    # Generate comprehensive suggestions
    suggestions = []
    
    if ai_probability > 30:
        suggestions.append(f"High AI detection ({ai_probability:.0f}%). Use the Humanize feature to make text more natural.")
    
    if writing_patterns["indicators"].get("high_consistency"):
        suggestions.append("Sentence lengths are too consistent. Vary your sentence structure.")
    
    if writing_patterns["indicators"].get("low_diversity"):
        suggestions.append("Vocabulary is repetitive. Use more varied word choices.")
    
    if not citation_analysis["has_reference_section"]:
        suggestions.append("Add a reference section to support your arguments.")
    
    if citation_analysis["total_citations"] < 3:
        suggestions.append("Include more in-text citations to support your claims.")
    
    if repeated_words:
        word_list = ', '.join([w['word'] for w in repeated_words[:3]])
        suggestions.append(f"Reduce repetition: {word_list}")
    
    if similarity > 15:
        suggestions.append("High internal similarity detected. Rephrase repeated ideas.")
    
    if not suggestions:
        suggestions.append("Excellent! Your essay shows strong human writing characteristics.")
    
    return AdvancedAnalysisResponse(
        score=original_score,
        human_score=human_score,
        ai_probability=round(ai_probability, 2),
        similarity=round(similarity, 2),
        ai_phrase_count=ai_phrase_count,
        sentence_variation=round(variation, 2),
        repeated_words=repeated_words,
        highlighted_text=highlighted_text,
        suggestions=suggestions,
        topic_analysis=topic_analysis,
        references=references,
        peer_reviewed_suggestions=peer_suggestions,
        writing_patterns=writing_patterns,
        citation_analysis=citation_analysis
    )

@app.post("/humanize")
def humanize_endpoint(request: HumanizeRequest):
    """
    Humanize AI-generated text.
    """
    text = request.text.strip()
    style = request.style
    
    if not text:
        raise HTTPException(status_code=400, detail="No text provided")
    
    humanized = humanize_text(text, style)
    
    # Re-analyze to show improvement
    original_ai_prob, _ = detect_advanced_ai_patterns(text)
    new_ai_prob, _ = detect_advanced_ai_patterns(humanized)
    
    return {
        "original": text,
        "humanized": humanized,
        "style": style,
        "improvement": {
            "original_ai_probability": round(original_ai_prob, 2),
            "new_ai_probability": round(new_ai_prob, 2),
            "reduction": round(original_ai_prob - new_ai_prob, 2)
        }
    }

@app.post("/check-references")
def check_references(request: EssayRequest):
    """
    Check and validate references in the essay.
    """
    text = request.text.strip()
    
    if not text:
        raise HTTPException(status_code=400, detail="No text provided")
    
    # Topic analysis for context
    topic_analysis = analyze_topic(text)
    
    # Extract references
    references = extract_references(text)
    
    # Suggest peer-reviewed sources
    peer_suggestions = suggest_peer_reviewed_references(
        topic_analysis.main_topic,
        topic_analysis.subtopics
    )
    
    # Citation analysis
    citation_analysis = analyze_citations(text)
    
    return {
        "topic": topic_analysis,
        "extracted_references": [r.dict() for r in references],
        "suggested_references": [r.dict() for r in peer_suggestions],
        "citation_analysis": citation_analysis,
        "recommendations": [
            "Ensure all in-text citations have corresponding entries in your reference list.",
            "Use peer-reviewed sources for academic credibility.",
            "Check citation format consistency throughout your essay."
        ]
    }

@app.post("/detect-ai")
def detect_ai(request: EssayRequest):
    """
    Advanced AI detection endpoint.
    """
    text = request.text.strip()
    
    if not text:
        raise HTTPException(status_code=400, detail="No text provided")
    
    ai_probability, patterns = detect_advanced_ai_patterns(text)
    writing_patterns = analyze_writing_patterns(text)
    
    # Categorize patterns
    pattern_summary = {}
    for category in AI_PATTERNS.keys():
        count = len([p for p in patterns if p.get("category") == category])
        if count > 0:
            pattern_summary[category] = count
    
    return {
        "ai_probability": round(ai_probability, 2),
        "is_likely_ai": ai_probability > 50,
        "pattern_summary": pattern_summary,
        "writing_patterns": writing_patterns,
        "detected_phrases": [
            {
                "phrase": text[p["start"]:p["end"]],
                "category": p.get("category"),
                "position": p["start"]
            }
            for p in patterns[:20]  # Limit to first 20
        ]
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
