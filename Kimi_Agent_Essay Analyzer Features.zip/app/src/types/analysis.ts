export type HighlightType = 'repetition' | 'ai_phrase' | 'long_sentence' | 'short_sentence' | 'good_example' | 'similarity' | 'no_examples' | 'ai_pattern';
export type Severity = 'low' | 'medium' | 'high';

export interface Highlight {
  start: number;
  end: number;
  type: HighlightType;
  severity: Severity;
  message: string;
  category?: string;
}

export interface RepeatedWord {
  word: string;
  count: number;
  percentage: number;
}

export interface TopicAnalysis {
  main_topic: string;
  subtopics: string[];
  keywords: string[];
  confidence: number;
}

export interface Reference {
  citation: string;
  type: 'apa' | 'mla' | 'chicago' | 'unknown';
  is_valid_format: boolean;
  matches_topic: boolean;
  suggested_correction?: string;
}

export interface PeerReviewedSource {
  title: string;
  authors: string;
  journal: string;
  year: number;
  doi: string;
  relevance_score: number;
  url: string;
}

export interface WritingPatterns {
  sentence_consistency: number;
  vocabulary_diversity: number;
  first_person_usage: number;
  contractions_used: number;
  avg_sentence_length: number;
  indicators: {
    high_consistency: boolean;
    low_diversity: boolean;
    low_first_person: boolean;
    few_contractions: boolean;
  };
}

export interface CitationAnalysis {
  apa_citations: number;
  mla_citations: number;
  total_citations: number;
  direct_quotes: number;
  paraphrase_indicators: number;
  citation_density: number;
  has_reference_section: boolean;
  quality_assessment: {
    sufficient_citations: boolean;
    good_paraphrasing: boolean;
    balanced_quotes: boolean;
  };
}

export interface AnalysisResult {
  score: number;
  human_score: number;
  ai_probability: number;
  similarity: number;
  ai_phrase_count: number;
  sentence_variation: number;
  repeated_words: RepeatedWord[];
  highlighted_text: Highlight[];
  suggestions: string[];
  topic_analysis: TopicAnalysis;
  references: Reference[];
  peer_reviewed_suggestions: PeerReviewedSource[];
  writing_patterns: WritingPatterns;
  citation_analysis: CitationAnalysis;
}

export interface HumanizeResponse {
  original: string;
  humanized: string;
  style: string;
  improvement: {
    original_ai_probability: number;
    new_ai_probability: number;
    reduction: number;
  };
}

export interface AIDetectionResponse {
  ai_probability: number;
  is_likely_ai: boolean;
  pattern_summary: Record<string, number>;
  writing_patterns: WritingPatterns;
  detected_phrases: Array<{
    phrase: string;
    category: string;
    position: number;
  }>;
}

export interface ReferenceCheckResponse {
  topic: TopicAnalysis;
  extracted_references: Reference[];
  suggested_references: PeerReviewedSource[];
  citation_analysis: CitationAnalysis;
  recommendations: string[];
}

export interface RewriteResponse {
  original: string;
  rewritten: string;
  message: string;
}

export interface ImproveParagraphResponse {
  paragraph: string;
  suggestions: string[];
}

export interface AddExampleResponse {
  paragraph: string;
  suggested_example: string;
  message: string;
}

export interface ReduceRepetitionResponse {
  word: string;
  synonyms: string[];
  message: string;
}
