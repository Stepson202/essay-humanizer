import type { 
  AnalysisResult, 
  HumanizeResponse,
  AIDetectionResponse,
  ReferenceCheckResponse,
  RewriteResponse, 
  ImproveParagraphResponse, 
  AddExampleResponse, 
  ReduceRepetitionResponse 
} from '@/types/analysis';

const API_BASE_URL = 'http://localhost:8000';

export async function analyzeEssay(text: string): Promise<AnalysisResult> {
  const response = await fetch(`${API_BASE_URL}/analyse`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to analyze essay');
  }

  return response.json();
}

export async function humanizeText(text: string, style: string = 'natural'): Promise<HumanizeResponse> {
  const response = await fetch(`${API_BASE_URL}/humanize`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text, style }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to humanize text');
  }

  return response.json();
}

export async function detectAI(text: string): Promise<AIDetectionResponse> {
  const response = await fetch(`${API_BASE_URL}/detect-ai`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to detect AI patterns');
  }

  return response.json();
}

export async function checkReferences(text: string): Promise<ReferenceCheckResponse> {
  const response = await fetch(`${API_BASE_URL}/check-references`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to check references');
  }

  return response.json();
}

export async function rewriteSentence(sentence: string): Promise<RewriteResponse> {
  const response = await fetch(`${API_BASE_URL}/rewrite`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ sentence }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to rewrite sentence');
  }

  return response.json();
}

export async function improveParagraph(paragraph: string): Promise<ImproveParagraphResponse> {
  const response = await fetch(`${API_BASE_URL}/improve-paragraph`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ paragraph }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to improve paragraph');
  }

  return response.json();
}

export async function addExample(paragraph: string, topic?: string): Promise<AddExampleResponse> {
  const response = await fetch(`${API_BASE_URL}/add-example`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ paragraph, topic }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to add example');
  }

  return response.json();
}

export async function reduceRepetition(text: string, word: string): Promise<ReduceRepetitionResponse> {
  const response = await fetch(`${API_BASE_URL}/reduce-repetition`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ text, word }),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Failed to get synonyms');
  }

  return response.json();
}
