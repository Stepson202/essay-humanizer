import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Toaster, toast } from 'sonner';
import { 
  FileText, 
  BarChart3, 
  Sparkles, 
  Upload, 
  Download,
  Loader2,
  ChevronRight,
  CheckCircle2,
  Brain,
  Repeat,
  AlertTriangle,
  Target,
  BookOpen,
  Wand2
} from 'lucide-react';
import { analyzeEssay } from '@/services/api';
import type { AnalysisResult, Highlight } from '@/types/analysis';
import { HighlightedText } from '@/components/essay/HighlightedText';
import { ScoreCard } from '@/components/essay/ScoreCard';
import { SuggestionsList } from '@/components/essay/SuggestionsList';
import { ActionButtons } from '@/components/essay/ActionButtons';
import { HighlightLegend } from '@/components/essay/HighlightLegend';
import { TopicAnalysisCard } from '@/components/essay/TopicAnalysisCard';
import { PeerReferencesCard } from '@/components/essay/PeerReferencesCard';
import { HumanizeCard } from '@/components/essay/HumanizeCard';
import { WritingPatternsCard } from '@/components/essay/WritingPatternsCard';
import { CitationAnalysisCard } from '@/components/essay/CitationAnalysisCard';
import './App.css';

// Sample essay for demo
const sampleEssay = `The Impact of Artificial Intelligence on Modern Education

Artificial intelligence has revolutionized various sectors, and education is no exception. Furthermore, it is important to note that AI-powered tools are transforming how students learn and teachers instruct. This essay will discuss the significant impact of artificial intelligence on modern education systems.

Moreover, personalized learning platforms use AI algorithms to adapt content to individual student needs. These systems analyze student performance data to identify knowledge gaps and provide targeted interventions. Additionally, AI chatbots and virtual tutors offer 24/7 support, answering student questions and providing explanations outside classroom hours.

According to Smith (2023), AI in education is expected to grow by 47% annually. Research shows that adaptive learning technologies can improve student outcomes by up to 30%. However, there are concerns about data privacy and the potential for algorithmic bias in educational AI systems.

In conclusion, while AI offers tremendous potential for enhancing education, it is crucial to implement these technologies thoughtfully. Educators must balance technological innovation with pedagogical best practices to ensure equitable access and positive learning outcomes for all students.

References:
Smith, J. (2023). AI in Education: Trends and Challenges. Journal of Educational Technology, 15(3), 45-62.`;

function App() {
  const [essayText, setEssayText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [selectedText, setSelectedText] = useState('');
  const [activeTab, setActiveTab] = useState('home');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleAnalyze = async () => {
    if (!essayText.trim() || essayText.trim().length < 50) {
      toast.error('Please enter at least 50 characters of text');
      return;
    }

    setIsAnalyzing(true);
    try {
      const analysisResult = await analyzeEssay(essayText);
      setResult(analysisResult);
      setActiveTab('results');
      toast.success('Analysis complete!');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to analyze essay');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleLoadSample = () => {
    setEssayText(sampleEssay);
    setActiveTab('editor');
    toast.info('Sample essay loaded');
  };

  const handleClear = () => {
    setEssayText('');
    setResult(null);
    toast.info('Text cleared');
  };

  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim()) {
      setSelectedText(selection.toString().trim());
    }
  };

  const handleExport = () => {
    if (!result) return;
    
    const exportData = {
      essay: essayText,
      analysis: result,
      exportedAt: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'essay-analysis.json';
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success('Analysis exported');
  };

  const handleHumanizedText = (text: string) => {
    setEssayText(text);
    toast.success('Humanized text applied to editor');
  };

  // Home Page Component
  const HomePage = () => (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-2xl mb-6">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            Essay Analyzer Pro
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Advanced AI detection and humanization. Understand your essay's topic, 
            validate references, and get peer-reviewed source suggestions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => setActiveTab('editor')}
              className="gap-2"
            >
              <FileText className="w-5 h-5" />
              Start Analyzing
              <ChevronRight className="w-4 h-4" />
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={handleLoadSample}
              className="gap-2"
            >
              <Upload className="w-5 h-5" />
              Try Sample Essay
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Advanced Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard 
              icon={<Target className="w-6 h-6" />}
              title="Topic Understanding"
              description="Automatically detects your essay's main topic and suggests relevant peer-reviewed sources."
            />
            <FeatureCard 
              icon={<Brain className="w-6 h-6" />}
              title="Advanced AI Detection"
              description="Detects AI patterns like Turnitin and Copyleaks with detailed pattern analysis."
            />
            <FeatureCard 
              icon={<Wand2 className="w-6 h-6" />}
              title="AI Humanizer"
              description="Transform AI-generated text into natural, human-like writing."
            />
            <FeatureCard 
              icon={<BookOpen className="w-6 h-6" />}
              title="Reference Validation"
              description="Check citations and get suggestions for peer-reviewed academic sources."
            />
            <FeatureCard 
              icon={<BarChart3 className="w-6 h-6" />}
              title="Writing Pattern Analysis"
              description="Analyze sentence consistency, vocabulary diversity, and human-like indicators."
            />
            <FeatureCard 
              icon={<Repeat className="w-6 h-6" />}
              title="Originality Check"
              description="Detect internal similarity and repetition for better originality."
            />
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-muted/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-8">
            <StepCard 
              number={1}
              title="Paste Essay"
              description="Enter your essay text."
            />
            <StepCard 
              number={2}
              title="AI Analysis"
              description="Advanced detection runs."
            />
            <StepCard 
              number={3}
              title="Review Results"
              description="See detailed insights."
            />
            <StepCard 
              number={4}
              title="Humanize"
              description="Make it natural."
            />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Analyze Your Essay?</h2>
          <p className="text-muted-foreground mb-8">
            Get comprehensive analysis with topic detection, reference validation, and AI humanization.
          </p>
          <Button 
            size="lg" 
            onClick={() => setActiveTab('editor')}
            className="gap-2"
          >
            <Sparkles className="w-5 h-5" />
            Get Started Free
          </Button>
        </div>
      </section>
    </div>
  );

  // Feature Card Component
  function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
    return (
      <Card className="hover:shadow-lg transition-shadow">
        <CardContent className="pt-6">
          <div className="p-3 bg-primary/10 rounded-xl w-fit mb-4">
            {icon}
          </div>
          <h3 className="font-semibold text-lg mb-2">{title}</h3>
          <p className="text-muted-foreground text-sm">{description}</p>
        </CardContent>
      </Card>
    );
  }

  // Step Card Component
  function StepCard({ number, title, description }: { number: number; title: string; description: string }) {
    return (
      <div className="text-center">
        <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
          {number}
        </div>
        <h3 className="font-semibold text-lg mb-2">{title}</h3>
        <p className="text-muted-foreground text-sm">{description}</p>
      </div>
    );
  }

  // Editor Page Component
  const EditorPage = () => (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">Essay Editor</h1>
          <p className="text-muted-foreground">Paste your essay and click Analyze to get comprehensive insights.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Editor Panel */}
          <div className="lg:col-span-2 space-y-4">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Your Essay
                </CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleLoadSample}>
                    Load Sample
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleClear}>
                    Clear
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Textarea
                  ref={textareaRef}
                  value={essayText}
                  onChange={(e) => setEssayText(e.target.value)}
                  onMouseUp={handleTextSelection}
                  placeholder="Paste your essay here... (minimum 50 characters)"
                  className="min-h-[400px] resize-none font-mono text-sm leading-relaxed"
                />
                <div className="mt-4 flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">
                    {essayText.length} characters | {essayText.split(/\s+/).filter(Boolean).length} words
                  </p>
                  <Button 
                    onClick={handleAnalyze} 
                    disabled={isAnalyzing}
                    size="lg"
                    className="gap-2"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        Analyze Essay
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <ActionButtons 
              selectedText={selectedText} 
              fullText={essayText}
            />
            
            {/* Humanize Card - Only show if we have results */}
            {result && (
              <HumanizeCard 
                essayText={essayText}
                currentAIProbability={result.ai_probability}
                onHumanized={handleHumanizedText}
              />
            )}
            
            <HighlightLegend />
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Quick Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    Include peer-reviewed references
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    Vary sentence lengths naturally
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    Use contractions for natural flow
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    Add personal voice and examples
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );

  // Results Page Component
  const ResultsPage = () => {
    if (!result) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="text-center">
            <AlertTriangle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">No Analysis Yet</h2>
            <p className="text-muted-foreground mb-4">Analyze an essay first to see results.</p>
            <Button onClick={() => setActiveTab('editor')}>
              Go to Editor
            </Button>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Analysis Results</h1>
              <p className="text-muted-foreground">Comprehensive analysis with topic detection and AI patterns.</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleExport} className="gap-2">
                <Download className="w-4 h-4" />
                Export
              </Button>
              <Button onClick={() => setActiveTab('editor')}>
                Back to Editor
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Panel - Analysis */}
            <div className="space-y-4">
              <ScoreCard 
                score={result.score}
                humanScore={result.human_score}
                aiProbability={result.ai_probability}
                similarity={result.similarity}
                aiPhraseCount={result.ai_phrase_count}
                sentenceVariation={result.sentence_variation}
                repeatedWordsCount={result.repeated_words.length}
              />
              
              <TopicAnalysisCard topicAnalysis={result.topic_analysis} />
              
              <WritingPatternsCard patterns={result.writing_patterns} />
              
              <SuggestionsList suggestions={result.suggestions} />
            </div>

            {/* Middle Panel - References & Citations */}
            <div className="space-y-4">
              <PeerReferencesCard references={result.peer_reviewed_suggestions} />
              
              <CitationAnalysisCard citationAnalysis={result.citation_analysis} />
              
              {/* Repeated Words Detail */}
              {result.repeated_words.length > 0 && (
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Repeated Words</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {result.repeated_words.slice(0, 5).map((word, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span className="font-medium">{word.word}</span>
                          <span className="text-muted-foreground">
                            {word.count} times ({word.percentage}%)
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Right Panel - Highlighted Text */}
            <div className="lg:col-span-1">
              <Card className="h-full">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Highlighted Essay
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[800px] pr-4">
                    <div 
                      className="prose prose-sm dark:prose-invert max-w-none"
                      onMouseUp={handleTextSelection}
                    >
                      <HighlightedText 
                        text={essayText}
                        highlights={result.highlighted_text}
                        onHighlightClick={(h: Highlight) => console.log(h)}
                      />
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Toaster position="top-right" richColors />
      
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div 
              className="flex items-center gap-2 cursor-pointer"
              onClick={() => setActiveTab('home')}
            >
              <div className="p-2 bg-primary/10 rounded-lg">
                <Sparkles className="w-5 h-5 text-primary" />
              </div>
              <span className="font-bold text-xl">Essay Analyzer Pro</span>
            </div>
            <div className="flex items-center gap-1">
              <Button 
                variant={activeTab === 'home' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('home')}
              >
                Home
              </Button>
              <Button 
                variant={activeTab === 'editor' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('editor')}
              >
                Editor
              </Button>
              <Button 
                variant={activeTab === 'results' ? 'default' : 'ghost'}
                onClick={() => setActiveTab('results')}
                disabled={!result}
              >
                Results
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        {activeTab === 'home' && <HomePage />}
        {activeTab === 'editor' && <EditorPage />}
        {activeTab === 'results' && <ResultsPage />}
      </main>

      {/* Footer */}
      <footer className="border-t py-6 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              <span className="font-semibold">Essay Analyzer Pro</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Advanced AI detection and humanization for better writing
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
