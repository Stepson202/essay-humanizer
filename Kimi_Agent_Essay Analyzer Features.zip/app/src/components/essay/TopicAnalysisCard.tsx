import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, Hash, Layers, Sparkles } from 'lucide-react';
import type { TopicAnalysis } from '@/types/analysis';

interface TopicAnalysisCardProps {
  topicAnalysis: TopicAnalysis;
}

export function TopicAnalysisCard({ topicAnalysis }: TopicAnalysisCardProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Target className="w-5 h-5 text-blue-500" />
          Topic Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Main Topic */}
        <div>
          <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            Detected Topic
          </p>
          <h3 className="text-lg font-semibold">{topicAnalysis.main_topic}</h3>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex-1 bg-muted rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all"
                style={{ width: `${topicAnalysis.confidence}%` }}
              />
            </div>
            <span className="text-xs text-muted-foreground">{topicAnalysis.confidence.toFixed(0)}% confidence</span>
          </div>
        </div>

        {/* Subtopics */}
        {topicAnalysis.subtopics.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
              <Layers className="w-3 h-3" />
              Subtopics
            </p>
            <div className="flex flex-wrap gap-1.5">
              {topicAnalysis.subtopics.map((subtopic, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {subtopic}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Keywords */}
        <div>
          <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
            <Hash className="w-3 h-3" />
            Key Terms
          </p>
          <div className="flex flex-wrap gap-1">
            {topicAnalysis.keywords.map((keyword, index) => (
              <span 
                key={index} 
                className="text-xs px-2 py-1 bg-muted rounded-md text-muted-foreground"
              >
                {keyword}
              </span>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
