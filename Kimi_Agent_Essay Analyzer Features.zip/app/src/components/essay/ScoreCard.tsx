import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Brain,
  Repeat,
  AlignLeft,
  FileText,
  User,
  Bot
} from 'lucide-react';

interface ScoreCardProps {
  score: number;
  humanScore: number;
  aiProbability: number;
  similarity: number;
  aiPhraseCount: number;
  sentenceVariation: number;
  repeatedWordsCount: number;
}

function getScoreColor(score: number): string {
  if (score >= 80) return 'text-green-500';
  if (score >= 60) return 'text-yellow-500';
  return 'text-red-500';
}

function getAIColor(probability: number): string {
  if (probability < 20) return 'text-green-500';
  if (probability < 50) return 'text-yellow-500';
  return 'text-red-500';
}

function getScoreIcon(score: number) {
  if (score >= 80) return <CheckCircle2 className="w-8 h-8 text-green-500" />;
  if (score >= 60) return <AlertTriangle className="w-8 h-8 text-yellow-500" />;
  return <XCircle className="w-8 h-8 text-red-500" />;
}

export function ScoreCard({ 
  humanScore,
  aiProbability,
  similarity, 
  aiPhraseCount, 
  sentenceVariation,
  repeatedWordsCount 
}: ScoreCardProps) {
  const scoreColor = getScoreColor(humanScore);
  const aiColor = getAIColor(aiProbability);

  return (
    <div className="space-y-4">
      {/* Main Human Score */}
      <Card className="border-2">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">Human Writing Score</p>
              <div className="flex items-baseline gap-2">
                <span className={cn("text-5xl font-bold", scoreColor)}>{humanScore}</span>
                <span className="text-xl text-muted-foreground">/ 100</span>
              </div>
            </div>
            <div className="p-3 bg-muted rounded-full">
              {getScoreIcon(humanScore)}
            </div>
          </div>
          <Progress 
            value={humanScore} 
            className="mt-4 h-3"
          />
          <p className="mt-3 text-sm text-muted-foreground">
            {humanScore >= 80 
              ? 'Excellent! Your essay shows strong human writing characteristics.' 
              : humanScore >= 60 
              ? 'Good, but there are areas for improvement.' 
              : 'Several AI-like patterns detected. Consider using the Humanize feature.'}
          </p>
        </CardContent>
      </Card>

      {/* AI Probability */}
      <Card className={cn(
        "border-2",
        aiProbability > 50 ? "border-red-200 dark:border-red-900" :
        aiProbability > 30 ? "border-yellow-200 dark:border-yellow-900" :
        "border-green-200 dark:border-green-900"
      )}>
        <CardContent className="pt-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Bot className="w-4 h-4" />
                AI Detection Probability
              </p>
              <div className="flex items-baseline gap-2">
                <span className={cn("text-4xl font-bold", aiColor)}>{aiProbability}%</span>
              </div>
            </div>
            <div className={cn(
              "p-3 rounded-full",
              aiProbability > 50 ? "bg-red-100 dark:bg-red-900/30" :
              aiProbability > 30 ? "bg-yellow-100 dark:bg-yellow-900/30" :
              "bg-green-100 dark:bg-green-900/30"
            )}>
              {aiProbability > 50 ? (
                <Bot className="w-6 h-6 text-red-500" />
              ) : aiProbability > 30 ? (
                <AlertTriangle className="w-6 h-6 text-yellow-500" />
              ) : (
                <User className="w-6 h-6 text-green-500" />
              )}
            </div>
          </div>
          <Progress 
            value={aiProbability} 
            className={cn(
              "mt-3 h-2",
              aiProbability > 50 ? "[&>div]:bg-red-500" :
              aiProbability > 30 ? "[&>div]:bg-yellow-500" :
              "[&>div]:bg-green-500"
            )}
          />
          <p className="mt-2 text-xs text-muted-foreground">
            {aiProbability > 50 
              ? 'High probability of AI-generated content detected.' 
              : aiProbability > 30 
              ? 'Some AI-like patterns present.' 
              : 'Low AI detection - appears to be human-written.'}
          </p>
        </CardContent>
      </Card>

      {/* Detailed Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Similarity */}
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                <FileText className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground">Similarity</p>
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-lg font-semibold",
                    similarity > 30 ? 'text-red-500' : similarity > 15 ? 'text-yellow-500' : 'text-green-500'
                  )}>
                    {similarity}%
                  </span>
                </div>
              </div>
            </div>
            <Progress 
              value={similarity} 
              className="mt-2 h-1.5"
            />
          </CardContent>
        </Card>

        {/* AI Phrases */}
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg">
                <Brain className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">AI Phrases</p>
                <span className={cn(
                  "text-lg font-semibold",
                  aiPhraseCount > 10 ? 'text-red-500' : aiPhraseCount > 5 ? 'text-yellow-500' : 'text-green-500'
                )}>
                  {aiPhraseCount}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sentence Variation */}
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                <AlignLeft className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Sentence Variation</p>
                <span className={cn(
                  "text-lg font-semibold",
                  sentenceVariation < 20 ? 'text-red-500' : sentenceVariation < 30 ? 'text-yellow-500' : 'text-green-500'
                )}>
                  {sentenceVariation.toFixed(1)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Repeated Words */}
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
                <Repeat className="w-5 h-5 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Repeated Words</p>
                <span className={cn(
                  "text-lg font-semibold",
                  repeatedWordsCount > 8 ? 'text-red-500' : repeatedWordsCount > 4 ? 'text-yellow-500' : 'text-green-500'
                )}>
                  {repeatedWordsCount}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
