import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BookOpen, Quote, RefreshCw, FileText, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import type { CitationAnalysis } from '@/types/analysis';

interface CitationAnalysisCardProps {
  citationAnalysis: CitationAnalysis;
}

export function CitationAnalysisCard({ citationAnalysis }: CitationAnalysisCardProps) {
  const { quality_assessment, has_reference_section } = citationAnalysis;

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-amber-500" />
          Citation Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Reference Section Status */}
        <div className={`p-3 rounded-lg ${has_reference_section ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'}`}>
          <div className="flex items-center gap-2">
            {has_reference_section ? (
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            ) : (
              <XCircle className="w-5 h-5 text-red-600" />
            )}
            <span className={has_reference_section ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}>
              {has_reference_section ? 'Reference section detected' : 'No reference section found'}
            </span>
          </div>
        </div>

        {/* Citation Counts */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-2 bg-muted rounded-lg text-center">
            <p className="text-2xl font-semibold">{citationAnalysis.total_citations}</p>
            <p className="text-xs text-muted-foreground">Total Citations</p>
          </div>
          <div className="p-2 bg-muted rounded-lg text-center">
            <p className="text-2xl font-semibold">{citationAnalysis.apa_citations}</p>
            <p className="text-xs text-muted-foreground">APA Style</p>
          </div>
          <div className="p-2 bg-muted rounded-lg text-center">
            <p className="text-2xl font-semibold">{citationAnalysis.mla_citations}</p>
            <p className="text-xs text-muted-foreground">MLA Style</p>
          </div>
        </div>

        {/* Citation Density */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Citation Density</span>
            </div>
            <span className={citationAnalysis.citation_density < 3 ? 'text-yellow-600 text-sm font-medium' : 'text-green-600 text-sm font-medium'}>
              {citationAnalysis.citation_density.toFixed(1)}/1000 words
            </span>
          </div>
          <Progress 
            value={Math.min(citationAnalysis.citation_density * 20, 100)} 
            className="h-1.5"
          />
          <p className="text-xs text-muted-foreground mt-1">
            {citationAnalysis.citation_density < 3 
              ? 'Consider adding more citations' 
              : 'Good citation density'}
          </p>
        </div>

        {/* Direct Quotes vs Paraphrasing */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <Quote className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Direct Quotes</span>
            </div>
            <p className={citationAnalysis.direct_quotes > 5 ? 'text-yellow-600 font-semibold' : 'text-green-600 font-semibold'}>
              {citationAnalysis.direct_quotes}
            </p>
          </div>
          <div className="p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <RefreshCw className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Paraphrases</span>
            </div>
            <p className={citationAnalysis.paraphrase_indicators < 2 ? 'text-yellow-600 font-semibold' : 'text-green-600 font-semibold'}>
              {citationAnalysis.paraphrase_indicators}
            </p>
          </div>
        </div>

        {/* Quality Assessment */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">Citation Quality</p>
          <div className="space-y-2">
            <div className={`flex items-center justify-between p-2 rounded-lg ${
              quality_assessment.sufficient_citations ? 'bg-green-50 dark:bg-green-900/20' : 'bg-yellow-50 dark:bg-yellow-900/20'
            }`}>
              <span className="text-sm">Citation Count</span>
              <Badge variant="outline" className={quality_assessment.sufficient_citations ? 'text-green-600' : 'text-yellow-600'}>
                {quality_assessment.sufficient_citations ? (
                  <><CheckCircle2 className="w-3 h-3 mr-1" /> Sufficient</>
                ) : (
                  <><AlertTriangle className="w-3 h-3 mr-1" /> Insufficient</>
                )}
              </Badge>
            </div>

            <div className={`flex items-center justify-between p-2 rounded-lg ${
              quality_assessment.good_paraphrasing ? 'bg-green-50 dark:bg-green-900/20' : 'bg-yellow-50 dark:bg-yellow-900/20'
            }`}>
              <span className="text-sm">Paraphrasing</span>
              <Badge variant="outline" className={quality_assessment.good_paraphrasing ? 'text-green-600' : 'text-yellow-600'}>
                {quality_assessment.good_paraphrasing ? (
                  <><CheckCircle2 className="w-3 h-3 mr-1" /> Good</>
                ) : (
                  <><AlertTriangle className="w-3 h-3 mr-1" /> Needs Work</>
                )}
              </Badge>
            </div>

            <div className={`flex items-center justify-between p-2 rounded-lg ${
              quality_assessment.balanced_quotes ? 'bg-green-50 dark:bg-green-900/20' : 'bg-yellow-50 dark:bg-yellow-900/20'
            }`}>
              <span className="text-sm">Quote Balance</span>
              <Badge variant="outline" className={quality_assessment.balanced_quotes ? 'text-green-600' : 'text-yellow-600'}>
                {quality_assessment.balanced_quotes ? (
                  <><CheckCircle2 className="w-3 h-3 mr-1" /> Balanced</>
                ) : (
                  <><AlertTriangle className="w-3 h-3 mr-1" /> Unbalanced</>
                )}
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
