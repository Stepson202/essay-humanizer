import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Wand2, Copy, CheckCircle2, TrendingDown, User } from 'lucide-react';
import { toast } from 'sonner';
import { humanizeText } from '@/services/api';

interface HumanizeCardProps {
  essayText: string;
  currentAIProbability: number;
  onHumanized?: (text: string) => void;
}

export function HumanizeCard({ essayText, currentAIProbability, onHumanized }: HumanizeCardProps) {
  const [isHumanizing, setIsHumanizing] = useState(false);
  const [humanizedText, setHumanizedText] = useState('');
  const [improvement, setImprovement] = useState<{
    original_ai_probability: number;
    new_ai_probability: number;
    reduction: number;
  } | null>(null);
  const [style, setStyle] = useState<'natural' | 'academic' | 'casual'>('natural');

  const handleHumanize = async () => {
    if (!essayText.trim()) {
      toast.error('No text to humanize');
      return;
    }

    setIsHumanizing(true);
    try {
      const result = await humanizeText(essayText, style);
      setHumanizedText(result.humanized);
      setImprovement(result.improvement);
      onHumanized?.(result.humanized);
      toast.success('Text humanized successfully!');
    } catch (error) {
      toast.error('Failed to humanize text');
    } finally {
      setIsHumanizing(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(humanizedText);
    toast.success('Copied to clipboard');
  };

  const applyHumanizedText = () => {
    onHumanized?.(humanizedText);
    toast.success('Humanized text applied to editor');
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Wand2 className="w-5 h-5 text-pink-500" />
          AI Humanizer
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Status */}
        <div className="p-3 bg-muted rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Current AI Probability</span>
            <Badge 
              variant={currentAIProbability > 50 ? "destructive" : currentAIProbability > 30 ? "default" : "secondary"}
            >
              {currentAIProbability.toFixed(1)}%
            </Badge>
          </div>
        </div>

        {/* Style Selection */}
        <div>
          <p className="text-xs text-muted-foreground mb-2">Humanization Style</p>
          <div className="flex gap-2">
            {(['natural', 'academic', 'casual'] as const).map((s) => (
              <Button
                key={s}
                variant={style === s ? 'default' : 'outline'}
                size="sm"
                onClick={() => setStyle(s)}
                className="capitalize flex-1"
              >
                {s}
              </Button>
            ))}
          </div>
        </div>

        {/* Humanize Button */}
        <Button 
          onClick={handleHumanize} 
          disabled={isHumanizing}
          className="w-full gap-2"
        >
          {isHumanizing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Humanizing...
            </>
          ) : (
            <>
              <Wand2 className="w-4 h-4" />
              Humanize Text
            </>
          )}
        </Button>

        {/* Results */}
        {humanizedText && improvement && (
          <div className="space-y-3 pt-2 border-t">
            {/* Improvement Stats */}
            <div className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-green-600" />
                <span className="text-sm text-green-700 dark:text-green-300">
                  AI probability reduced by {improvement.reduction.toFixed(1)}%
                </span>
              </div>
              <CheckCircle2 className="w-4 h-4 text-green-600" />
            </div>

            {/* New AI Probability */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">New AI Probability</span>
              <Badge 
                variant={improvement.new_ai_probability > 50 ? "destructive" : improvement.new_ai_probability > 30 ? "default" : "secondary"}
              >
                {improvement.new_ai_probability.toFixed(1)}%
              </Badge>
            </div>

            {/* Preview */}
            <div>
              <p className="text-xs text-muted-foreground mb-2">Preview (first 200 chars)</p>
              <div className="p-3 bg-muted rounded-lg text-sm">
                {humanizedText.slice(0, 200)}...
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={copyToClipboard}
                className="flex-1"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
              <Button 
                size="sm" 
                onClick={applyHumanizedText}
                className="flex-1"
              >
                <User className="w-4 h-4 mr-2" />
                Apply to Editor
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
