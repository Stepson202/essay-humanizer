import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Info } from 'lucide-react';

const legendItems = [
  { color: 'bg-red-200 dark:bg-red-900/50', label: 'Repetition', description: 'Words used too frequently' },
  { color: 'bg-yellow-200 dark:bg-yellow-900/50', label: 'AI Phrases', description: 'Common AI-generated phrases' },
  { color: 'bg-orange-200 dark:bg-orange-900/50', label: 'AI Patterns', description: 'Advanced AI detection patterns' },
  { color: 'bg-blue-200 dark:bg-blue-900/50', label: 'Long Sentences', description: 'Sentences over 25 words' },
  { color: 'bg-purple-200 dark:bg-purple-900/50', label: 'Short Sentences', description: 'Sentences under 5 words' },
  { color: 'bg-green-200 dark:bg-green-900/50', label: 'Good Examples', description: 'Proper use of examples' },
  { color: 'bg-amber-200 dark:bg-amber-900/50', label: 'Similar Phrases', description: 'Repeated phrases or ideas' },
];

export function HighlightLegend() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Info className="w-4 h-4" />
          Highlight Legend
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {legendItems.map((item, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className={`w-4 h-4 rounded ${item.color}`} />
              <div className="flex-1">
                <span className="text-xs font-medium">{item.label}</span>
                <span className="text-xs text-muted-foreground ml-1">- {item.description}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
