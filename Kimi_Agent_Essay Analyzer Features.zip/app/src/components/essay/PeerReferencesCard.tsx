import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink, Copy, GraduationCap } from 'lucide-react';
import { toast } from 'sonner';
import type { PeerReviewedSource } from '@/types/analysis';

interface PeerReferencesCardProps {
  references: PeerReviewedSource[];
}

export function PeerReferencesCard({ references }: PeerReferencesCardProps) {
  const copyCitation = (ref: PeerReviewedSource) => {
    const citation = `${ref.authors} (${ref.year}). ${ref.title}. ${ref.journal}. https://doi.org/${ref.doi}`;
    navigator.clipboard.writeText(citation);
    toast.success('Citation copied to clipboard');
  };

  if (references.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-purple-500" />
            Suggested References
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            No specific references found for this topic. Try adding more specific keywords to your essay.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-purple-500" />
          Suggested Peer-Reviewed References
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {references.map((ref, index) => (
            <div key={index} className="p-3 bg-muted/50 rounded-lg">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-sm line-clamp-2">{ref.title}</h4>
                  <p className="text-xs text-muted-foreground mt-1">{ref.authors}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-muted-foreground">{ref.journal}</span>
                    <span className="text-xs text-muted-foreground">•</span>
                    <span className="text-xs text-muted-foreground">{ref.year}</span>
                  </div>
                </div>
                <Badge 
                  variant={ref.relevance_score > 70 ? "default" : "secondary"}
                  className="text-xs shrink-0"
                >
                  {ref.relevance_score.toFixed(0)}% match
                </Badge>
              </div>
              <div className="flex items-center gap-2 mt-3">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-7 text-xs"
                  onClick={() => copyCitation(ref)}
                >
                  <Copy className="w-3 h-3 mr-1" />
                  Copy Citation
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-7 text-xs"
                  onClick={() => window.open(ref.url, '_blank')}
                >
                  <ExternalLink className="w-3 h-3 mr-1" />
                  View Source
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
