import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FileText, BarChart3, User, MessageSquare, AlertTriangle, CheckCircle2 } from 'lucide-react';
import type { WritingPatterns } from '@/types/analysis';

interface WritingPatternsCardProps {
  patterns: WritingPatterns;
}

export function WritingPatternsCard({ patterns }: WritingPatternsCardProps) {
  const { indicators } = patterns;

  const getIndicatorStatus = (isFlagged: boolean) => 
    isFlagged ? 
      { icon: AlertTriangle, color: 'text-yellow-500', bg: 'bg-yellow-50 dark:bg-yellow-900/20', label: 'AI-like' } :
      { icon: CheckCircle2, color: 'text-green-500', bg: 'bg-green-50 dark:bg-green-900/20', label: 'Human-like' };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-indigo-500" />
          Writing Pattern Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Metrics */}
        <div className="grid grid-cols-2 gap-3">
          {/* Vocabulary Diversity */}
          <div className="p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Vocabulary Diversity</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className={patterns.vocabulary_diversity < 40 ? 'text-yellow-600 font-semibold' : 'text-green-600 font-semibold'}>
                {patterns.vocabulary_diversity.toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={patterns.vocabulary_diversity} 
              className="mt-2 h-1.5"
            />
          </div>

          {/* First Person Usage */}
          <div className="p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <User className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">First Person</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className={patterns.first_person_usage < 1 ? 'text-yellow-600 font-semibold' : 'text-green-600 font-semibold'}>
                {patterns.first_person_usage.toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={Math.min(patterns.first_person_usage * 10, 100)} 
              className="mt-2 h-1.5"
            />
          </div>
        </div>

        {/* Sentence Consistency */}
        <div className="p-3 bg-muted rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Sentence Consistency</span>
            </div>
            <span className={patterns.sentence_consistency > 70 ? 'text-yellow-600 text-sm font-medium' : 'text-green-600 text-sm font-medium'}>
              {patterns.sentence_consistency.toFixed(1)}%
            </span>
          </div>
          <Progress 
            value={patterns.sentence_consistency} 
            className="h-1.5"
          />
          <p className="text-xs text-muted-foreground mt-1">
            {patterns.sentence_consistency > 70 
              ? 'Very consistent - may indicate AI generation' 
              : 'Good variation in sentence structure'}
          </p>
        </div>

        {/* Indicators */}
        <div>
          <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
            <MessageSquare className="w-3 h-3" />
            Human vs AI Indicators
          </p>
          <div className="space-y-2">
            {/* High Consistency */}
            <div className={`flex items-center justify-between p-2 rounded-lg ${getIndicatorStatus(indicators.high_consistency).bg}`}>
              <span className="text-sm">Sentence Consistency</span>
              <Badge variant="outline" className={`text-xs ${getIndicatorStatus(indicators.high_consistency).color}`}>
                {getIndicatorStatus(indicators.high_consistency).icon === AlertTriangle && <AlertTriangle className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.high_consistency).icon === CheckCircle2 && <CheckCircle2 className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.high_consistency).label}
              </Badge>
            </div>

            {/* Low Diversity */}
            <div className={`flex items-center justify-between p-2 rounded-lg ${getIndicatorStatus(indicators.low_diversity).bg}`}>
              <span className="text-sm">Vocabulary Diversity</span>
              <Badge variant="outline" className={`text-xs ${getIndicatorStatus(indicators.low_diversity).color}`}>
                {getIndicatorStatus(indicators.low_diversity).icon === AlertTriangle && <AlertTriangle className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.low_diversity).icon === CheckCircle2 && <CheckCircle2 className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.low_diversity).label}
              </Badge>
            </div>

            {/* Low First Person */}
            <div className={`flex items-center justify-between p-2 rounded-lg ${getIndicatorStatus(indicators.low_first_person).bg}`}>
              <span className="text-sm">Personal Voice</span>
              <Badge variant="outline" className={`text-xs ${getIndicatorStatus(indicators.low_first_person).color}`}>
                {getIndicatorStatus(indicators.low_first_person).icon === AlertTriangle && <AlertTriangle className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.low_first_person).icon === CheckCircle2 && <CheckCircle2 className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.low_first_person).label}
              </Badge>
            </div>

            {/* Few Contractions */}
            <div className={`flex items-center justify-between p-2 rounded-lg ${getIndicatorStatus(indicators.few_contractions).bg}`}>
              <span className="text-sm">Natural Language</span>
              <Badge variant="outline" className={`text-xs ${getIndicatorStatus(indicators.few_contractions).color}`}>
                {getIndicatorStatus(indicators.few_contractions).icon === AlertTriangle && <AlertTriangle className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.few_contractions).icon === CheckCircle2 && <CheckCircle2 className="w-3 h-3 mr-1" />}
                {getIndicatorStatus(indicators.few_contractions).label}
              </Badge>
            </div>
          </div>
        </div>

        {/* Contractions Count */}
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Contractions Used</span>
          <span className={patterns.contractions_used < 3 ? 'text-yellow-600 font-medium' : 'text-green-600 font-medium'}>
            {patterns.contractions_used}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
