import { useMemo } from 'react';
import type { Highlight } from '@/types/analysis';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface HighlightedTextProps {
  text: string;
  highlights: Highlight[];
  onHighlightClick?: (highlight: Highlight) => void;
}

const highlightColors: Record<Highlight['type'], string> = {
  repetition: 'bg-red-200 dark:bg-red-900/50 text-red-900 dark:text-red-100',
  ai_phrase: 'bg-yellow-200 dark:bg-yellow-900/50 text-yellow-900 dark:text-yellow-100',
  ai_pattern: 'bg-orange-200 dark:bg-orange-900/50 text-orange-900 dark:text-orange-100',
  long_sentence: 'bg-blue-200 dark:bg-blue-900/50 text-blue-900 dark:text-blue-100',
  short_sentence: 'bg-purple-200 dark:bg-purple-900/50 text-purple-900 dark:text-purple-100',
  good_example: 'bg-green-200 dark:bg-green-900/50 text-green-900 dark:text-green-100',
  similarity: 'bg-amber-200 dark:bg-amber-900/50 text-amber-900 dark:text-amber-100',
  no_examples: 'bg-gray-200 dark:bg-gray-800 text-gray-900 dark:text-gray-100 border-b-2 border-dashed border-gray-500',
};

const severityIndicators: Record<Highlight['severity'], string> = {
  low: 'border-l-2 border-green-400',
  medium: 'border-l-2 border-yellow-400',
  high: 'border-l-2 border-red-400',
};

const highlightLabels: Record<Highlight['type'], string> = {
  repetition: 'Repetition',
  ai_phrase: 'AI Phrase',
  ai_pattern: 'AI Pattern',
  long_sentence: 'Long Sentence',
  short_sentence: 'Short Sentence',
  good_example: 'Good Example',
  similarity: 'Similar Phrase',
  no_examples: 'No Examples',
};

export function HighlightedText({ text, highlights, onHighlightClick }: HighlightedTextProps) {
  const segments = useMemo(() => {
    // Sort highlights by start position
    const sortedHighlights = [...highlights].sort((a, b) => a.start - b.start);
    
    const result: Array<{
      type: 'text' | 'highlight';
      content: string;
      highlight?: Highlight;
    }> = [];
    
    let currentPos = 0;
    
    for (const highlight of sortedHighlights) {
      // Add text before highlight
      if (highlight.start > currentPos) {
        result.push({
          type: 'text',
          content: text.slice(currentPos, highlight.start),
        });
      }
      
      // Add highlighted text
      result.push({
        type: 'highlight',
        content: text.slice(highlight.start, highlight.end),
        highlight,
      });
      
      currentPos = highlight.end;
    }
    
    // Add remaining text
    if (currentPos < text.length) {
      result.push({
        type: 'text',
        content: text.slice(currentPos),
      });
    }
    
    return result;
  }, [text, highlights]);

  if (!highlights.length) {
    return <div className="whitespace-pre-wrap">{text}</div>;
  }

  return (
    <TooltipProvider>
      <div className="whitespace-pre-wrap leading-relaxed">
        {segments.map((segment, index) => {
          if (segment.type === 'text') {
            return <span key={index}>{segment.content}</span>;
          }

          const highlight = segment.highlight!;
          const colorClass = highlightColors[highlight.type];
          const severityClass = severityIndicators[highlight.severity];
          const label = highlightLabels[highlight.type];

          return (
            <Tooltip key={index}>
              <TooltipTrigger asChild>
                <span
                  className={`${colorClass} ${severityClass} px-1 rounded cursor-pointer transition-all hover:opacity-80`}
                  onClick={() => onHighlightClick?.(highlight)}
                >
                  {segment.content}
                </span>
              </TooltipTrigger>
              <TooltipContent side="top" className="max-w-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-xs">{label}</p>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                      highlight.severity === 'high' ? 'bg-red-100 text-red-700' :
                      highlight.severity === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {highlight.severity}
                    </span>
                  </div>
                  <p className="text-sm">{highlight.message}</p>
                  {highlight.category && (
                    <p className="text-xs text-muted-foreground">Category: {highlight.category}</p>
                  )}
                </div>
              </TooltipContent>
            </Tooltip>
          );
        })}
      </div>
    </TooltipProvider>
  );
}
