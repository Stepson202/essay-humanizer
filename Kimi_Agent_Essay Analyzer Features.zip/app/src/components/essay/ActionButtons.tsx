import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  RefreshCw, 
  Sparkles, 
  PlusCircle, 
  Minimize2,
  Loader2,
  Check,
  Copy
} from 'lucide-react';
import { 
  rewriteSentence, 
  improveParagraph, 
  addExample, 
  reduceRepetition 
} from '@/services/api';
import { toast } from 'sonner';

interface ActionButtonsProps {
  selectedText: string;
  fullText: string;
}

export function ActionButtons({ selectedText, fullText }: ActionButtonsProps) {
  const [isRewriting, setIsRewriting] = useState(false);
  const [isImproving, setIsImproving] = useState(false);
  const [isAddingExample, setIsAddingExample] = useState(false);
  const [isReducing, setIsReducing] = useState(false);
  
  const [rewrittenText, setRewrittenText] = useState('');
  const [improvements, setImprovements] = useState<string[]>([]);
  const [exampleSuggestion, setExampleSuggestion] = useState('');
  const [synonyms, setSynonyms] = useState<string[]>([]);
  const [selectedWord, setSelectedWord] = useState('');

  const handleRewrite = async () => {
    if (!selectedText) {
      toast.error('Please select text to rewrite');
      return;
    }
    
    setIsRewriting(true);
    try {
      const result = await rewriteSentence(selectedText);
      setRewrittenText(result.rewritten);
      toast.success('Sentence rewritten successfully');
    } catch (error) {
      toast.error('Failed to rewrite sentence');
    } finally {
      setIsRewriting(false);
    }
  };

  const handleImprove = async () => {
    const textToImprove = selectedText || fullText.split('\n\n')[0];
    if (!textToImprove) {
      toast.error('No text to improve');
      return;
    }
    
    setIsImproving(true);
    try {
      const result = await improveParagraph(textToImprove);
      setImprovements(result.suggestions);
      toast.success('Improvement suggestions generated');
    } catch (error) {
      toast.error('Failed to generate improvements');
    } finally {
      setIsImproving(false);
    }
  };

  const handleAddExample = async () => {
    const textToImprove = selectedText || fullText.split('\n\n')[0];
    if (!textToImprove) {
      toast.error('No paragraph selected');
      return;
    }
    
    setIsAddingExample(true);
    try {
      const result = await addExample(textToImprove);
      setExampleSuggestion(result.suggested_example);
      toast.success('Example suggestion generated');
    } catch (error) {
      toast.error('Failed to generate example');
    } finally {
      setIsAddingExample(false);
    }
  };

  const handleReduceRepetition = async () => {
    // Extract a potentially repeated word from selected text
    const word = selectedText.split(' ')[0];
    if (!word || word.length < 4) {
      toast.error('Please select a word to find synonyms for');
      return;
    }
    
    setSelectedWord(word);
    setIsReducing(true);
    try {
      const result = await reduceRepetition(fullText, word);
      setSynonyms(result.synonyms);
      toast.success('Synonyms found');
    } catch (error) {
      toast.error('Failed to find synonyms');
    } finally {
      setIsReducing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-500" />
          AI Writing Assistant
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2">
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleRewrite}
                disabled={isRewriting}
                className="justify-start"
              >
                {isRewriting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Rewrite
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Rewritten Sentence</DialogTitle>
                <DialogDescription>
                  AI-optimized version of your selected text
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium mb-2">Original:</p>
                  <div className="p-3 bg-muted rounded-lg text-sm">{selectedText}</div>
                </div>
                <div>
                  <p className="text-sm font-medium mb-2">Rewritten:</p>
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg text-sm">
                    {rewrittenText}
                  </div>
                </div>
                <Button 
                  onClick={() => copyToClipboard(rewrittenText)}
                  variant="outline" 
                  size="sm"
                  className="w-full"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Rewritten Text
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleImprove}
                disabled={isImproving}
                className="justify-start"
              >
                {isImproving ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4 mr-2" />
                )}
                Improve
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Improvement Suggestions</DialogTitle>
                <DialogDescription>
                  Tips to enhance your paragraph
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                {improvements.map((improvement, index) => (
                  <div 
                    key={index} 
                    className="p-3 bg-muted rounded-lg text-sm flex items-start gap-2"
                  >
                    <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                    {improvement}
                  </div>
                ))}
              </div>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleAddExample}
                disabled={isAddingExample}
                className="justify-start"
              >
                {isAddingExample ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <PlusCircle className="w-4 h-4 mr-2" />
                )}
                Add Example
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Example Suggestion</DialogTitle>
                <DialogDescription>
                  Add this example to your paragraph
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg text-sm">
                  {exampleSuggestion}
                </div>
                <Button 
                  onClick={() => copyToClipboard(exampleSuggestion)}
                  variant="outline" 
                  size="sm"
                  className="w-full"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Example
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleReduceRepetition}
                disabled={isReducing}
                className="justify-start"
              >
                {isReducing ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Minimize2 className="w-4 h-4 mr-2" />
                )}
                Synonyms
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Synonym Suggestions</DialogTitle>
                <DialogDescription>
                  Alternative words for "{selectedWord}"
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-wrap gap-2">
                {synonyms.map((synonym, index) => (
                  <button
                    key={index}
                    onClick={() => copyToClipboard(synonym)}
                    className="px-3 py-2 bg-muted hover:bg-muted/80 rounded-lg text-sm transition-colors"
                  >
                    {synonym}
                  </button>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {selectedText && (
          <p className="mt-3 text-xs text-muted-foreground">
            Selected: "{selectedText.slice(0, 50)}{selectedText.length > 50 ? '...' : ''}"
          </p>
        )}
      </CardContent>
    </Card>
  );
}
