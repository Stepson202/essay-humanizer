@echo off
echo ===================================
echo   Essay Analyzer Pro - Launcher
echo ===================================
echo.

echo Installing backend dependencies...
cd backend
pip install -q fastapi uvicorn pydantic python-multipart 2>nul
echo [OK] Backend dependencies installed

echo.
echo Starting backend server on http://localhost:8000
start python main.py

echo Waiting for backend to start...
timeout /t 3 /nobreak >nul

cd ..

echo.
echo Installing frontend dependencies...
call npm install -q 2>nul
echo [OK] Frontend dependencies installed

echo.
echo Starting frontend on http://localhost:5173
start npm run dev

echo.
echo ===================================
echo   Both servers are starting!
echo ===================================
echo.
echo   Frontend: http://localhost:5173
echo   Backend:  http://localhost:8000
echo   API Docs: http://localhost:8000/docs
echo.
pause
