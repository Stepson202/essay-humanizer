# Essay Analyzer Pro

A full-stack web application with advanced AI detection, topic understanding, reference validation, and humanization features. Built with React + TypeScript + Tailwind CSS frontend and Python FastAPI backend.

![Essay Analyzer Pro](https://via.placeholder.com/800x400?text=Essay+Analyzer+Pro)

## Live Demo
**Frontend:** https://gxzi34rs5zrlm.ok.kimi.link

## New Advanced Features

### 1. Topic Understanding
- Automatically extracts the main topic from your essay
- Identifies subtopics and key terms
- Provides confidence score for topic detection

### 2. Peer-Reviewed Reference Suggestions
- Suggests relevant academic sources based on your topic
- Includes DOI, journal info, and direct links
- Relevance scoring for each suggestion

### 3. Advanced AI Detection (Turnitin/Copyleaks-like)
Detects 7 categories of AI patterns:
- **Transitional Phrases** - Overused transitions
- **AI Introductions** - Robotic opening patterns
- **AI Conclusions** - Formulaic closing statements
- **Robotic Phrases** - Mechanical expressions
- **Generic Statements** - Vague, overused claims
- **AI Fillers** - Unnecessary padding phrases
- **Academic Buzzwords** - Clichéd terminology

### 4. AI Humanizer
- Transform AI-generated text into natural writing
- Three styles: Natural, Academic, Casual
- Shows AI probability reduction after humanization

### 5. Writing Pattern Analysis
- Sentence consistency detection
- Vocabulary diversity scoring
- First-person usage analysis
- Contraction usage (natural language indicator)

### 6. Citation Analysis
- APA/MLA citation detection
- Citation density scoring
- Direct quotes vs paraphrasing balance
- Reference section validation

## Tech Stack

### Frontend
- React 18 + TypeScript
- Vite (build tool)
- Tailwind CSS 3.4
- shadcn/ui components
- Lucide React icons

### Backend
- Python 3.8+
- FastAPI
- Uvicorn (ASGI server)
- Pydantic (data validation)

## Project Structure

```
essay-analyzer/
├── backend/
│   ├── main.py              # FastAPI application with advanced analysis
│   └── requirements.txt     # Python dependencies
├── src/
│   ├── components/essay/
│   │   ├── ActionButtons.tsx          # AI Writing Assistant buttons
│   │   ├── CitationAnalysisCard.tsx   # Citation quality analysis
│   │   ├── HighlightedText.tsx        # Text with color highlights
│   │   ├── HighlightLegend.tsx        # Color legend for highlights
│   │   ├── HumanizeCard.tsx           # AI Humanizer component
│   │   ├── PeerReferencesCard.tsx     # Peer-reviewed suggestions
│   │   ├── ScoreCard.tsx              # Score display component
│   │   ├── SuggestionsList.tsx        # Improvement suggestions
│   │   ├── TopicAnalysisCard.tsx      # Topic detection display
│   │   └── WritingPatternsCard.tsx    # Writing pattern analysis
│   ├── services/
│   │   └── api.ts                     # API client functions
│   ├── types/
│   │   └── analysis.ts                # TypeScript type definitions
│   ├── App.tsx                        # Main application
│   ├── App.css                        # Custom styles
│   └── main.tsx                       # Entry point
├── README.md
└── package.json
```

## Installation & Setup

### Step 1: Install Frontend Dependencies

```bash
cd /mnt/okcomputer/output/app
npm install
```

### Step 2: Install Backend Dependencies

```bash
cd /mnt/okcomputer/output/app/backend
pip install -r requirements.txt
```

### Step 3: Start the Backend Server

```bash
cd /mnt/okcomputer/output/app/backend
python main.py
```

The backend will start on `http://localhost:8000`

### Step 4: Start the Frontend (New Terminal)

```bash
cd /mnt/okcomputer/output/app
npm run dev
```

The frontend will start on `http://localhost:5173`

### Step 5: Open in Browser

Navigate to `http://localhost:5173` to use the application.

## API Endpoints

### POST `/analyse`
Advanced essay analysis with topic detection and AI patterns.

**Response includes:**
- `score` - Original compatibility score
- `human_score` - Enhanced human writing score (0-100)
- `ai_probability` - AI detection probability (%)
- `similarity` - Internal similarity score
- `topic_analysis` - Detected topic, subtopics, keywords
- `peer_reviewed_suggestions` - Recommended academic sources
- `writing_patterns` - Human vs AI indicators
- `citation_analysis` - Citation quality metrics

### POST `/humanize`
Transform AI-generated text into natural writing.

**Request:**
```json
{
  "text": "Furthermore, it is important to note that...",
  "style": "natural"  // natural, academic, casual
}
```

**Response:**
```json
{
  "original": "Furthermore, it is important to note that...",
  "humanized": "Also, keep in mind that...",
  "improvement": {
    "original_ai_probability": 65.5,
    "new_ai_probability": 25.3,
    "reduction": 40.2
  }
}
```

### POST `/detect-ai`
Advanced AI detection with pattern categorization.

### POST `/check-references`
Validate references and get peer-reviewed suggestions.

## Scoring System

### Human Writing Score (0-100)
- **Start:** 100 points
- **AI Probability > 50%:** -30 points
- **AI Probability > 30%:** -20 points
- **AI Probability > 15%:** -10 points
- **High sentence consistency:** -10 points
- **Low vocabulary diversity:** -10 points
- **Low first-person usage:** -5 points
- **Few contractions:** -5 points
- **Low sentence variation:** -10 points
- **High repetition:** -10 points
- **High similarity:** -15 points

### AI Detection Probability
Calculated using weighted pattern detection:
- AI Introductions: 3.0x weight
- AI Conclusions: 2.5x weight
- Robotic Phrases: 2.0x weight
- Generic Statements: 1.5x weight
- AI Fillers: 1.5x weight
- Academic Buzzwords: 0.8x weight
- Transitional Phrases: 0.5x weight

## Highlight Colors

| Color | Meaning |
|-------|---------|
| 🔴 Red | Repetition |
| 🟡 Yellow | AI Phrases |
| 🟠 Orange | AI Patterns |
| 🔵 Blue | Long Sentences (>25 words) |
| 🟣 Purple | Short Sentences (<5 words) |
| 🟢 Green | Good Example Usage |
| 🟤 Amber | Similar Phrases |

## Humanization Features

The AI Humanizer:
1. Replaces AI phrases with natural alternatives
2. Adds contractions for conversational flow
3. Varies sentence structure
4. Removes robotic transitions
5. Adapts to selected style (Natural/Academic/Casual)

## Peer-Reviewed Database

Currently includes curated sources for:
- Climate Change
- Artificial Intelligence
- Education
- Psychology
- Economics
- Healthcare
- Technology
- Sustainability
- Social Media
- Leadership

## Development

### Frontend Development

```bash
# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Backend Development

```bash
cd backend

# Run with auto-reload
uvicorn main:app --reload --host 0.0.0.0 --port 8000

# Run normally
python main.py
```

### API Documentation

When the backend is running, visit:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Environment Variables

### Frontend
Create `.env` file in project root:
```
VITE_API_URL=http://localhost:8000
```

### Backend
Create `.env` file in `backend/` directory:
```
PORT=8000
HOST=0.0.0.0
```

## Building for Production

### Frontend
```bash
npm run build
```
Output will be in `dist/` directory.

### Backend
No build step required. Deploy the `backend/` directory with Python.

## Deployment

### Frontend (Static Hosting)
1. Build: `npm run build`
2. Deploy `dist/` folder to Vercel, Netlify, or any static host

### Backend (Server)
Deploy `backend/` folder to Heroku, Railway, AWS, or any Python-compatible host

## Troubleshooting

### CORS Errors
Ensure backend CORS allows your frontend URL in `main.py`:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    ...
)
```

### Port Conflicts
Change ports in:
- Backend: `main.py` (port 8000)
- Frontend: `vite.config.ts` (port 5173)

## License

MIT License - free for personal and commercial use.

## Acknowledgments

- Built with [shadcn/ui](https://ui.shadcn.com/) components
- Icons by [Lucide](https://lucide.dev/)
- Powered by [FastAPI](https://fastapi.tiangolo.com/)
