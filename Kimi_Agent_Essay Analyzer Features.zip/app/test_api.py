#!/usr/bin/env python3
"""Test script to verify the Essay Analyzer API is working."""

import requests
import json
import sys

def test_backend():
    BASE_URL = "http://localhost:8000"
    
    print("=" * 50)
    print("Essay Analyzer Pro - API Test")
    print("=" * 50)
    
    # Test 1: Health Check
    print("\n1. Testing health endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/", timeout=5)
        if response.status_code == 200:
            print(f"   ✓ Backend is running: {response.json()}")
        else:
            print(f"   ✗ Unexpected status: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("   ✗ Cannot connect to backend!")
        print("   Make sure the backend is running: python backend/main.py")
        return False
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    # Test 2: Analyze Essay
    print("\n2. Testing analyze endpoint...")
    test_essay = """The Impact of Artificial Intelligence on Education

Artificial intelligence has revolutionized various sectors, and education is no exception. Furthermore, it is important to note that AI-powered tools are transforming how students learn and teachers instruct. This essay will discuss the significant impact of artificial intelligence on modern education systems.

Moreover, personalized learning platforms use AI algorithms to adapt content to individual student needs. These systems analyze student performance data to identify knowledge gaps and provide targeted interventions.

According to Smith (2023), AI in education is expected to grow by 47% annually. Research shows that adaptive learning technologies can improve student outcomes by up to 30%.

References:
Smith, J. (2023). AI in Education: Trends and Challenges. Journal of Educational Technology, 15(3), 45-62.
"""
    
    try:
        response = requests.post(
            f"{BASE_URL}/analyse",
            json={"text": test_essay},
            timeout=10
        )
        
        if response.status_code == 200:
            result = response.json()
            print("   ✓ Analysis successful!")
            print(f"\n   Results:")
            print(f"   - Human Score: {result.get('human_score', 'N/A')}/100")
            print(f"   - AI Probability: {result.get('ai_probability', 'N/A')}%")
            print(f"   - Similarity: {result.get('similarity', 'N/A')}%")
            print(f"   - Topic: {result.get('topic_analysis', {}).get('main_topic', 'N/A')}")
            print(f"   - AI Phrases Found: {result.get('ai_phrase_count', 'N/A')}")
            print(f"   - Peer References Suggested: {len(result.get('peer_reviewed_suggestions', []))}")
        else:
            print(f"   ✗ Analysis failed: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"   ✗ Error: {e}")
        return False
    
    # Test 3: Humanize
    print("\n3. Testing humanize endpoint...")
    try:
        response = requests.post(
            f"{BASE_URL}/humanize",
            json={"text": "Furthermore, it is important to note that AI is changing education.", "style": "natural"},
            timeout=5
        )
        
        if response.status_code == 200:
            result = response.json()
            print("   ✓ Humanization successful!")
            print(f"   Original AI: {result['improvement']['original_ai_probability']}%")
            print(f"   After Humanize: {result['improvement']['new_ai_probability']}%")
            print(f"   Reduction: {result['improvement']['reduction']}%")
        else:
            print(f"   ✗ Humanization failed: {response.status_code}")
    except Exception as e:
        print(f"   ✗ Error: {e}")
    
    print("\n" + "=" * 50)
    print("All tests passed! Backend is working correctly.")
    print("=" * 50)
    return True

if __name__ == "__main__":
    success = test_backend()
    sys.exit(0 if success else 1)
